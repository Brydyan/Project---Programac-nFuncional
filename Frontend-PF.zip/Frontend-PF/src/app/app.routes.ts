import { Routes } from '@angular/router';
import { AuthComponent } from './pages/auth/auth';

export const routes: Routes = [

  { path: 'auth', component: AuthComponent },

  {
    path: 'dashboard',
    loadComponent: () =>
      import('./pages/dashboard/dashboard').then(m => m.Dashboard),

    children: [
      {
        path: 'chat/:contactId',
        loadComponent: () =>
          import('./pages/dashboard/chat-thread/chat-thread')
            .then(m => m.ChatThread)
      },

      // Ruta por defecto dentro del dashboard
      { path: '', redirectTo: 'chat/123', pathMatch: 'full' }
    ]
  },

  { path: '', redirectTo: 'auth', pathMatch: 'full' }
];
